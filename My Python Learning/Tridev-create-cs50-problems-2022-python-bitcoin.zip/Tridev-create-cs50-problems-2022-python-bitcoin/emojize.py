import emoji

Emoji = input('Input: ')
print(emoji.emojize(f'Output: {Emoji}'))
